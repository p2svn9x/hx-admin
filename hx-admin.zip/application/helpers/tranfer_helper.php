<?php
//tao ra cac link trong admin
function tranfer_url($url = '')
{
    return base_url('tranfer/'.$url);
}