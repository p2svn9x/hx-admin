<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.1.1
    </div>
    <strong>Copyright &copy; 2018 <a href="#">Sổ số miền bắc</a>.</strong> All rights
    reserved.
</footer>