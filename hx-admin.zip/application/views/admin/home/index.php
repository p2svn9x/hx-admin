<div class="content-wrapper">
<section class="content-header">
    <h1>
        Trang chủ
    </h1>
</section>
<section class="content">
<div class="row">
<section class="col-lg-12 connectedSortable">
<div class="box box-success">

</div>
</section>

</div>
</section>
</div>

